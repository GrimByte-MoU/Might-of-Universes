using Terraria;
using Terraria.ModLoader;

namespace VanillaAccessoryBuffs
{
    public class FrogLegBuff : GlobalItem
    {
        public override void ModifyTooltips(Item item, System.Collections.Generic.List<TooltipLine> tooltips)
        {
            // Add tooltip modification here
        }

        public override void UpdateAccessory(Item item, Player player, bool hideVisual)
        {
            // Add accessory effects here
        }
    }
}